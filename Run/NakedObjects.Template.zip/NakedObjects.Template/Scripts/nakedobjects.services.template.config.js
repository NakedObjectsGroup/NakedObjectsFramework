/// <reference path="typings/lodash/lodash.d.ts" />
var NakedObjects;
(function (NakedObjects) {
    NakedObjects.app.run(function (template) {
        //Specify custom templates to associate with specific domain types e.g.
        //template.setTemplateName("myNameSpace.Foo", TemplateType.Object, InteractionMode.View, "Content/customTemplates/fooView.html");
        //template.setTemplateName("myNameSpace.Bar", TemplateType.List, CollectionViewState.List, "Content/customTemplates/barList.html");
    });
})(NakedObjects || (NakedObjects = {}));
//# sourceMappingURL=nakedobjects.services.template.config.js.map