/// <reference path="typings/lodash/lodash.d.ts" />
var NakedObjects;
(function (NakedObjects) {
    NakedObjects.app.run(function (template) {
        // template.setTemplateName("AdventureWorksModel.Product", InteractionMode.View, "Content/partials/customObjectView.html");
    });
})(NakedObjects || (NakedObjects = {}));
//# sourceMappingURL=nakedobjects.services.template.config.js.map