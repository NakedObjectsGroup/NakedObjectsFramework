module NakedObjects { export const version = "8.2.0" }
