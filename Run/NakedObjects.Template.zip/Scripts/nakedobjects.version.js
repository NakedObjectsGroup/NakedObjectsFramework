var NakedObjects;
(function (NakedObjects) {
    NakedObjects.version = "8.2.0";
})(NakedObjects || (NakedObjects = {}));
//# sourceMappingURL=nakedobjects.version.js.map