var NakedObjects;
(function (NakedObjects) {
    NakedObjects.version = "8.3.1";
})(NakedObjects || (NakedObjects = {}));
//# sourceMappingURL=nakedobjects.version.js.map