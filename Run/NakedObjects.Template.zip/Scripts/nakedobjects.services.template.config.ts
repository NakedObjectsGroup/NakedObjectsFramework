/// <reference path="typings/lodash/lodash.d.ts" />


module NakedObjects {
    app.run((template: ITemplate) => {
       // template.setTemplateName("AdventureWorksModel.Product", InteractionMode.View, "Content/partials/customObjectView.html");
    });
}