var NakedObjects;
(function (NakedObjects) {
    NakedObjects.version = "8.0.0-rc";
})(NakedObjects || (NakedObjects = {}));
//# sourceMappingURL=nakedobjects.version.js.map