/// <reference path="typings/lodash/lodash.d.ts" />


module NakedObjects {
    app.run((template: ITemplate) => {
        //template.setTemplateName("AdventureWorksModel.Product", TemplateType.Object, InteractionMode.View, "Content/customTemplates/openbydefaultObjectView.html");
        //template.setTemplateName("AdventureWorksModel.Product", TemplateType.Object, InteractionMode.View, "Content/customTemplates/withActionButtonObjectView.html");
        //template.setTemplateName("AdventureWorksModel.Product", TemplateType.Object, InteractionMode.View, "Content/customTemplates/withGroupedPropertiesObjectView.html");
        //template.setTemplateName("AdventureWorksModel.Product", TemplateType.Object, InteractionMode.View, "Content/customTemplates/withAccordionObjectView.html");
        //template.setTemplateName("AdventureWorksModel.Product", TemplateType.Object, InteractionMode.View, "Content/customTemplates/pollingObjectView.html");
        //template.setTemplateName("AdventureWorksModel.Product", TemplateType.List, CollectionViewState.List, "Content/customTemplates/productList.html");
    });
}