module NakedObjects { export const version = "8.0.0-rc4" }
