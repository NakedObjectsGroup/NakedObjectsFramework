module NakedObjects { export const version = "8.3.1" }
